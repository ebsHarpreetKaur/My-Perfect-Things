const assets = {
    lottieFiles: {
      planePath: require('./planePath.json'),
      like: require('./like.json'),
      unLike: require('./unLike.json'),
    },
  };
  
  export default assets;