const BASE_URL_FOR_PAGES = "https://myperfectthings.com/wp-json/wp/v2/pages"
const BASE_URL_FOR_POSTS = "https://myperfectthings.com/wp-json/wp/v2/posts"

export {
    BASE_URL_FOR_PAGES,
    BASE_URL_FOR_POSTS
}